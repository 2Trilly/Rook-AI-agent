# Put ROOK on your iPhone — no coding needed

This guide uses GitHub Pages, which can host a static site for free under GitHub's current terms. You do not need to buy a domain.

## Part 1 — Make the website

**Do this on your iPhone:**

1. Download and open `ROOK-Finished.zip` in the Files app.
2. Tap the ZIP once to unzip it. You should see a folder called `ROOK-Finished`.
3. In Safari, open **https://github.com** and sign in or create an account.
4. Tap the **+** menu and choose **New repository**.
5. Name it `rook-assistant`. Set it to **Public** if you want to use GitHub Pages on the free plan. Do not put private information or API keys in the repository.
6. Create the repository.
7. Open the repository and choose **Add file → Upload files**.
8. In the Files picker, open the unzipped `ROOK-Finished` folder. Upload the *contents inside it* (such as `index.html`, `app.js`, `styles.css`, `assets`, and `docs`) — not the ZIP itself and not an extra nested folder.
9. Wait for uploads to finish, then tap **Commit changes**.

> If the iPhone picker won't let you select multiple items or folders, the simplest route is to use a computer for this upload step. You can still use ROOK on your iPhone afterward. Never paste secret keys into GitHub.

## Part 2 — Turn on GitHub Pages

1. In your repository, open **Settings**.
2. Find **Pages** in the repository settings.
3. Under **Build and deployment**, set Source to **Deploy from a branch**.
4. Choose branch `main` and folder `/(root)`.
5. Tap **Save**.
6. Wait a few minutes and refresh the Pages screen. GitHub will show a website address similar to `https://YOUR-USERNAME.github.io/rook-assistant/`.

If you don't see the site right away, check the repository's **Actions** tab for the Pages deployment status and confirm `index.html` is at the repository's root.

## Part 3 — Add it to your iPhone home screen

1. Open the published address in **Safari** (not an in-app browser if possible).
2. Tap the **Share** icon.
3. Choose **Add to Home Screen**.
4. Name it ROOK and tap **Add**.

Now ROOK should appear like an app icon. The static site and local features don't cost anything under this setup, subject to GitHub's current terms.

## What will work without extra services?
- Chat's honest local-mode helper
- Memories and notes saved in that browser
- Export/import backup
- Search launchers that open Google/Bing/YouTube/Reddit
- Apple app links and any iCloud Shortcuts you add
- Cached app shell after first load

## What won't magically work?
A static GitHub Pages site does not include a powerful AI model, a live web-search API, a secure server, or unrestricted iPhone control. Those need external services and/or permissions. Do not add a paid key to a public website. Provider policies and free tiers can change.

## If something goes wrong
- **Blank page:** check that `index.html` is at the repository root, not inside another folder.
- **Old version:** wait a minute, then reload Safari; if needed, close and reopen the tab.
- **It won't install:** use Safari, open the exact published URL, then Share → Add to Home Screen.
- **Memories disappeared:** browser site data may have been cleared. Import a JSON backup if you exported one.
