# ROOK + Apple Shortcuts

ROOK is a website, so it cannot silently operate the whole iPhone. Apple Shortcuts can bridge specific actions after you create and approve them.

## Add a shortcut to ROOK
1. Open the Shortcuts app.
2. Create a shortcut and give it a clear name.
3. Add only actions you understand and trust. For actions that send a message, share information, delete content, or change settings, keep a confirmation step.
4. Open the shortcut's details/share menu and copy its iCloud link if available.
5. Open ROOK → iPhone actions.
6. Paste the shortcut's name and link into the form.

ROOK will display an Open button. iOS may show a confirmation or may open the Shortcuts app.

## Good starter shortcuts
- Open your school/day apps
- Start a focus timer
- Create a new note (review the note content before saving)
- Open a chosen playlist
- Open Maps to a saved destination
- Start a packing/checklist routine

## Privacy and safety
Review each shortcut before using it. Avoid shortcuts from strangers that ask for passwords, send messages, share location, install profiles, or upload personal files. ROOK does not have permission to bypass iOS safeguards.
