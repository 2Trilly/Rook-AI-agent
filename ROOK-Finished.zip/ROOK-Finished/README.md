# ROOK — Always in your corner

ROOK is a local-first, mobile-friendly personal assistant shell. This version is usable as a static website/PWA and does not require an account, an API key, or paid services for its local tools.

## What works now
- Responsive chat interface with honest local-mode fallback
- Optional compatible AI chat endpoint configuration
- Local memory with add/edit/delete
- Local notes with create/delete
- Export/import JSON backup
- Live web search launcher (Google, Bing, YouTube, Reddit search)
- Apple app links and user-added iCloud Shortcut buttons
- PWA manifest and service worker for install/offline shell

## Important limits
Local mode is not a real language model. It uses simple built-in responses. Web research opens your browser's search engine; it does not fetch or verify listings itself. Prices must be checked on the retailer's page. iOS does not allow a web app to control every app or silently perform every action.

An AI provider is optional. Its availability, CORS behavior, data handling, and prices are controlled by that provider and may change. This app stores a configured API key in this browser's local storage, which is **not secure for a public app**. Do not put a paid or sensitive key in a public deployment. A production app should use a server-side proxy with proper authentication and rate limits; that is outside a free static GitHub Pages site.

## Use it on iPhone for free
1. Unzip this folder.
2. Upload the contents to a GitHub repository.
3. In the repository, open **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Wait for GitHub Pages to publish the site.
6. Open the published `https://...github.io/.../` address in **Safari** on iPhone.
7. Tap **Share → Add to Home Screen**.

More detailed steps are in `docs/GITHUB_FOR_BEGINNERS.md`.

## Privacy
Notes, memories, chat history, settings, and shortcut links are stored in the browser on this device. They are not encrypted and can be lost if browser site data is cleared. Use Export data to make a backup. Do not store passwords, financial account numbers, or sensitive private information. If you configure an AI provider, messages and selected memories are sent to that provider when you chat.

## Project files
- `index.html` — app structure
- `styles.css` — design and responsive layout
- `app.js` — local features and optional AI endpoint
- `sw.js` — static offline shell
- `manifest.webmanifest` — installable PWA metadata
- `docs/SHORTCUTS.md` — iPhone Shortcut setup
- `docs/GITHUB_FOR_BEGINNERS.md` — simple deployment walkthrough

## License
MIT. See `LICENSE`.
